# Portfolio
Static site. Upload all files to a repo named <username>.github.io, then Settings > Pages > Deploy from branch (main, root).
